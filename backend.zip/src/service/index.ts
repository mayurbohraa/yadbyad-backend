import * as AuthenticationService from "./authentication.service";
import * as SettingsService from "./settings.service";
import * as ScheduleService from "./schedule.service";
import * as ComplainService from "./Complain.service";
import * as ReportService from "./report.service";
import * as ReportSlotService from "./report.service";
import * as ResourceService from "./resource.service";
import * as NotificationService from "./notification.service";
import * as CasualService from "./casual.service";
import * as LectureService from "./lecture.service";

export { AuthenticationService, SettingsService, ScheduleService,ComplainService, ReportService, 
    ReportSlotService, ResourceService,NotificationService,CasualService,
    LectureService,  };
