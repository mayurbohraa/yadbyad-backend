const multer = require('multer');
const cloudinary = require('cloudinary').v2;
const { CloudinaryStorage } = require('multer-storage-cloudinary');
// import CloudinaryStorage from "multer-storage-cloudinary";

cloudinary.config({
    cloud_name: process.env.CLOUD_NAME,
    api_key: process.env.CLOUD_API_KEY,
    api_secret: process.env.CLOUD_API_SECRET,
});

const storage = new CloudinaryStorage({
    cloudinary: cloudinary,
    params: {
        folder:"report_DEV",
        // allowerdFormats: ["png", "jpg", "jpeg"],
    },
});

const upload = multer({ storage: storage });

module.exports = {
    cloudinary, storage, multer
};